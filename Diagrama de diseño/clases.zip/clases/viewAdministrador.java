

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:11:55
 */
public class viewAdministrador {

	public viewAdministrador(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderAdmin(){

	}

	public void renderLista(){

	}
}//end viewAdministrador