

/**
 * ew
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:15
 */
public class ViewSesionCerrada {

	public ViewSesionCerrada(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderLisatSesionesCerradas(){

	}

	public void renderSesionCerrada(){

	}
}//end ViewSesionCerrada