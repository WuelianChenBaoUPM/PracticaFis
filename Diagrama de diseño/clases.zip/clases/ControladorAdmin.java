

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:13
 */
public class ControladorAdmin {

	public viewAdministrador m_viewAdministrador;
	public Administrador m_Administrador;

	public ControladorAdmin(){

	}

	public void finalize() throws Throwable {

	}
	public Administrador crearAdmin(){
		return null;
	}

	public int getTelefono(){
		return 0;
	}

	public String listaAdmins(){
		return "";
	}
}//end ControladorAdmin