

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:11:58
 */
public class BDUsGenerico implements IAccesoBDUsuarioGenerico {

	public BDUsGenerico(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param usGenerico
	 */
	public actualizar(UsuarioGenerico usGenerico){

	}

	/**
	 * 
	 * @param nombreUsuario
	 */
	public borrar(String nombreUsuario){

	}

	/**
	 * 
	 * @param usGenerico
	 */
	public insertar(UsuarioGenerico usGenerico){

	}

	/**
	 * 
	 * @param nombreUsuario
	 */
	public seleccionar(String nombreUsuario){

	}
}//end BDUsGenerico