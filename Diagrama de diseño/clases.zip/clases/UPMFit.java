

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:12
 */
public class UPMFit {

	public <<controller>ControladorUsGenerico m_<<controller>ControladorUsGenerico;
	public ControladorAdmin m_ControladorAdmin;
	public ControladorCliente m_ControladorCliente;
	public ControladorMonitor m_ControladorMonitor;
	public viewCurso m_viewCurso;
	public Curso m_Curso;

	public UPMFit(){

	}

	public void finalize() throws Throwable {

	}
	private void init(){

	}

	public void main(){

	}

	public String operate(){
		return "";
	}
}//end UPMFit