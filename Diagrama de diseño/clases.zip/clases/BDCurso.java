

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:05
 */
public class BDCurso implements IAccesoBDCurso {

	public BDCurso(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param curso
	 */
	public actualizar(Curso curso){

	}

	/**
	 * 
	 * @param curso
	 */
	public borrar(Curso curso){

	}

	/**
	 * 
	 * @param curso
	 */
	public insertar(Curso curso){

	}

	/**
	 * 
	 * @param curso
	 */
	public seleccionar(Curso curso){

	}
}//end BDCurso