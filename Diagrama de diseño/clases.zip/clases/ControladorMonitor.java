

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:15
 */
public class ControladorMonitor {

	public ViewMonitor m_ViewMonitor;
	public InterfazMonitor m_InterfazMonitor;

	public ControladorMonitor(){

	}

	public void finalize() throws Throwable {

	}
	public Monitor crearMonitor(){
		return null;
	}

	public String listaMonitores(){
		return "";
	}
}//end ControladorMonitor