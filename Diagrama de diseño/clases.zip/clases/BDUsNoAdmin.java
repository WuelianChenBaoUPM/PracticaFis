

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:00
 */
public class BDUsNoAdmin implements IAccesoBDUSNoAdmin {

	public BDUsNoAdmin(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param usNoAdmin
	 */
	public actualizar(UsuarioNoAdmin usNoAdmin){

	}

	/**
	 * 
	 * @param dni
	 */
	public borrar(String dni){

	}

	/**
	 * 
	 * @param usNoAdmin
	 */
	public insertar(UsuarioNoAdmin usNoAdmin){

	}

	/**
	 * 
	 * @param dni
	 */
	public seleccionar(String dni){

	}
}//end BDUsNoAdmin