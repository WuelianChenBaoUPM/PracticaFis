

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:11:55
 */
public class viewCurso {

	public viewCurso(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderCurso(){

	}

	public void renderListaCursos(){

	}
}//end viewCurso