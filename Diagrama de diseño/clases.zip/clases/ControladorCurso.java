

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:14
 */
public class ControladorCurso {

	public Curso m_Curso;
	public viewCurso m_viewCurso;

	public ControladorCurso(){

	}

	public void finalize() throws Throwable {

	}
	public Curso crearCurso(){
		return null;
	}

	public String listaCursos(){
		return "";
	}
}//end ControladorCurso