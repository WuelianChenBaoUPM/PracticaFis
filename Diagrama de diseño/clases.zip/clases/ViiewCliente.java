

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:11:56
 */
public class ViiewCliente {

	public ViiewCliente(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderCliente(){

	}

	public void renderListaCliente(){

	}
}//end ViiewCliente