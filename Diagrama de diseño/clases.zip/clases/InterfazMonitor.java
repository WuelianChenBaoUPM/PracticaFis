

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:11
 */
public interface InterfazMonitor {

	public void cobrar();

	public String getNumeroCuenta();

	/**
	 * 
	 * @param numCuenta
	 */
	public void setNumeroCuenta(String numCuenta);

}