

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:11:54
 */
public class InscripcionCurso {

	private int fechaInscripcion;
	public Cliente Clientes;
	public Curso Cursos;

	public InscripcionCurso(){

	}

	public void finalize() throws Throwable {

	}
	public destroy(){

	}

	public int getFechaIns(){
		return 0;
	}

	/**
	 * 
	 * @param fechaInscripcion
	 */
	public new(int fechaInscripcion){

	}

	public void setFechaInscripcion(){

	}
}//end InscripcionCurso