

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:09
 */
public interface InterfazAdministrador {

	public void altaMonitor();

	public double getTelefono();

	/**
	 * 
	 * @param numTelefono
	 */
	public void setNumTelefono(double numTelefono);

}