

/**
 * @author The Administrator
 * @version 1.0
 * @created 28-abr.-2023 0:12:12
 */
public class ViewMonitor {

	public ViewMonitor(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderListaMonitores(){

	}

	public void renderMonitor(){

	}
}//end ViewMonitor