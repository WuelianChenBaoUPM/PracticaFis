

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:13
 */
public interface IAccesoBDAdmin {

	/**
	 * 
	 * @param admin
	 */
	public actualizar(Administrador admin);

	/**
	 * 
	 * @param num
	 */
	public borrar(int num);

	/**
	 * 
	 * @param admin
	 */
	public insertar(Administrador admin);

	/**
	 * 
	 * @param num
	 */
	public seleccionar(int num);

}