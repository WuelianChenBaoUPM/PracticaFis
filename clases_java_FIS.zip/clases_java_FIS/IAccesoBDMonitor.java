

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:21
 */
public interface IAccesoBDMonitor {

	/**
	 * 
	 * @param monitor
	 */
	public actualizar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public borrar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public insertar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public seleccionar(Monitor monitor);

}