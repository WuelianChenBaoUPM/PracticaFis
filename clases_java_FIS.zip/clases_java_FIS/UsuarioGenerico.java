

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:32:57
 */
public class UsuarioGenerico implements Interfaz UsuarioGenerico {

	private String contrase�a;
	private String correoElectronico;
	private String nombre;
	private String nombreUsuario;

	public UsuarioGenerico(){

	}

	public void finalize() throws Throwable {

	}
	public destroy(){

	}

	public String getContrase�a(){
		return "";
	}

	public String getCorreo(){
		return "";
	}

	public String getNombre(){
		return "";
	}

	public String getNombreUsuario(){
		return "";
	}

	public void login(){

	}

	public void logOut(){

	}

	/**
	 * 
	 * @param contrase�a
	 * @param nombre
	 * @param nombreUsuario
	 * @param correoElectronico
	 */
	public new(String contrase�a, String nombre, String nombreUsuario, String correoElectronico){

	}

	public void setContrase�a(){

	}

	public void setCorreo(){

	}

	public void setNombre(){

	}

	/**
	 * 
	 * @param nombreUsusario
	 */
	public void setNombreUsuario(String nombreUsusario){

	}

	public void logIn(){

	}

	/**
	 * 
	 * @param contrase�a
	 */
	public void setContrase�a(String contrase�a){

	}

	/**
	 * 
	 * @param correo
	 */
	public void setCorreo(String correo){

	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre){

	}
}//end UsuarioGenerico