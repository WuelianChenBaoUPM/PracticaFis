

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:24
 */
public interface Interfaz UsuarioGenerico {

	public String getContrase�a();

	public String getCorreo();

	public String getNombre();

	public String getNombreUsuario();

	public void logIn();

	public void logOut();

	/**
	 * 
	 * @param contrase�a
	 */
	public void setContrase�a(String contrase�a);

	/**
	 * 
	 * @param correo
	 */
	public void setCorreo(String correo);

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre);

	/**
	 * 
	 * @param nombre
	 */
	public void setNombreUsuario(String nombre);

}