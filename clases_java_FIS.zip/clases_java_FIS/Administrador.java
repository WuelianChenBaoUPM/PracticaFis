

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:00
 */
public class Administrador extends UsuarioGenerico implements Interfaz Administrador {

	private int numeroDeTelefono;

	public Administrador(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void altaMonitor(){

	}

	public destroy(){

	}

	public int getTelefono(){
		return 0;
	}

	/**
	 * 
	 * @param numeroTelf
	 * @param contrase�a
	 * @param correoElectronico
	 * @param nombre
	 * @param nombreUsuario
	 */
	public new(int numeroTelf, String contrase�a, String correoElectronico, String nombre, String nombreUsuario){

	}

	/**
	 * 
	 * @param numeroTelefono
	 */
	public void setNumeroDeTelefono(int numeroTelefono){

	}

	/**
	 * 
	 * @param numTelefono
	 */
	public void setNumTelefono(double numTelefono){

	}
}//end Administrador