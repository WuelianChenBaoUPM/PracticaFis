

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:08
 */
public class Interfaz Gr�fica Sesion {

	public Interfaz Gr�fica Sesion(){

	}

	public void finalize() throws Throwable {

	}
	public String getActividad(){
		return "";
	}

	public int getAforo(){
		return 0;
	}

	public void getDatos(){

	}

	public String getHoraFin(){
		return "";
	}

	public String getHoraInicio(){
		return "";
	}

	/**
	 * 
	 * @param actividad
	 */
	public void setActividad(String actividad){

	}

	/**
	 * 
	 * @param aforo
	 */
	public void setAforo(int aforo){

	}

	/**
	 * 
	 * @param aforo
	 * @param actividad
	 * @param horaFin
	 * @param horaInicio
	 */
	public void setDatos(int aforo, String actividad, String horaFin, String horaInicio){

	}

	/**
	 * 
	 * @param hora
	 */
	public void setHoraFin(String hora){

	}

	/**
	 * 
	 * @param hora
	 */
	public void setHoraInicio(String hora){

	}
}//end Interfaz Gr�fica Sesion