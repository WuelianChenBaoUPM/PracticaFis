

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:10
 */
public class ViiewCliente {

	public ViiewCliente(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderCliente(){

	}

	public void renderListaCliente(){

	}
}//end ViiewCliente