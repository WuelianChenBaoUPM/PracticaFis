

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:30
 */
public class <<system>>UPMFit {

	public <<controller>ControladorUsGenerico m_<<controller>ControladorUsGenerico;
	public ControladorAdmin m_ControladorAdmin;
	public ControladorCliente m_ControladorCliente;
	public ControladorMonitor m_ControladorMonitor;
	public viewCurso m_viewCurso;
	public Curso m_Curso;

	public <<system>>UPMFit(){

	}

	public void finalize() throws Throwable {

	}
	private void init(){

	}

	public void main(){

	}

	public String operate(){
		return "";
	}
}//end <<system>>UPMFit