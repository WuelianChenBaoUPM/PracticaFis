

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:23
 */
public interface IAccesoBDSesionCerrada {

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void actualizar(SesionCerrada sesionCerrada);

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void borrar(SesionCerrada sesionCerrada);

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void insertar(SesionCerrada sesionCerrada);

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void seleccionar(SesionCerrada sesionCerrada);

}