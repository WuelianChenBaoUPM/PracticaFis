

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:07
 */
public class viewAdministrador {

	public viewAdministrador(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderAdmin(){

	}

	public void renderLista(){

	}
}//end viewAdministrador