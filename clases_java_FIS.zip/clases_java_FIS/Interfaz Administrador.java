

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:25
 */
public interface Interfaz Administrador {

	public void altaMonitor();

	public double getTelefono();

	/**
	 * 
	 * @param numTelefono
	 */
	public void setNumTelefono(double numTelefono);

}