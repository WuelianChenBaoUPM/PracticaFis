

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:34
 */
public class ControladorMonitor {

	public ViewMonitor m_ViewMonitor;
	public Interfaz Monitor m_Interfaz Monitor;

	public ControladorMonitor(){

	}

	public void finalize() throws Throwable {

	}
	public Monitor crearMonitor(){
		return null;
	}

	public String listaMonitores(){
		return "";
	}
}//end ControladorMonitor