

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:16
 */
public class BDAdmin implements IAccesoBDAdmin {

	public BDAdmin(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param admin
	 */
	public actualizar(Administrador admin){

	}

	/**
	 * 
	 * @param num
	 */
	public borrar(int num){

	}

	/**
	 * 
	 * @param admin
	 */
	public insertar(Administrador admin){

	}

	/**
	 * 
	 * @param num
	 */
	public seleccionar(int num){

	}
}//end BDAdmin