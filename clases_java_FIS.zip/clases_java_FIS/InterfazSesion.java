

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:36
 */
public interface InterfazSesion {

	public TActividad getActividad();

	public int getAforo();

	public int getHoraFin();

	public int getHoraInicio();

	public void setActividad();

	public void setAforo();

	public void setHoraFin();

	public void setHoraInicio();

}