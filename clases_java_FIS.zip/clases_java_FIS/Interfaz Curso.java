

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:27
 */
public interface Interfaz Curso {

	public date getFechaFin();

	public date getFechaInicio();

	public time getHorario();

	public String getNombre();

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaFin(date fecha);

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaInicio(date fecha);

	/**
	 * 
	 * @param horario
	 */
	public void setHorario(String horario);

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre);

}