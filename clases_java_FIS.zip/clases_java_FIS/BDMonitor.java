

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:19
 */
public class BDMonitor implements IAccesoBDMonitor {

	public BDMonitor(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param monitor
	 */
	public actualizar(Monitor monitor){

	}

	/**
	 * 
	 * @param monitor
	 */
	public borrar(Monitor monitor){

	}

	/**
	 * 
	 * @param monitor
	 */
	public insertar(Monitor monitor){

	}

	/**
	 * 
	 * @param monitor
	 */
	public seleccionar(Monitor monitor){

	}
}//end BDMonitor