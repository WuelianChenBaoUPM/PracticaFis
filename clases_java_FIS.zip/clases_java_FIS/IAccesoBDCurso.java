

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:19
 */
public interface IAccesoBDCurso {

	/**
	 * 
	 * @param curso
	 */
	public actualizar(Curso curso);

	/**
	 * 
	 * @param curso
	 */
	public borrar(Curso curso);

	/**
	 * 
	 * @param curso
	 */
	public insertar(Curso curso);

	/**
	 * 
	 * @param curso
	 */
	public seleccionar(Curso curso);

}