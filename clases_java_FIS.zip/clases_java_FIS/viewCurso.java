

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:09
 */
public class viewCurso {

	public viewCurso(){

	}

	public void finalize() throws Throwable {

	}
	public void new(){

	}

	public void renderCurso(){

	}

	public void renderListaCursos(){

	}
}//end viewCurso