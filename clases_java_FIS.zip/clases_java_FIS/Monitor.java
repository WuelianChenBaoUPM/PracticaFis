

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:01
 */
public class Monitor extends UsuarioNoAdmin implements Interfaz Monitor {

	private int numeroDeCuenta;

	public Monitor(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void cobrar(){

	}

	public int getNumeroCuenta(){
		return 0;
	}

	/**
	 * 
	 * @param numeroDeCuenta
	 * @param dni
	 * @param contrase�a
	 * @param correoElectronico
	 * @param nombre
	 * @param nombreUsuario
	 */
	public void new(int numeroDeCuenta, String dni, String contrase�a, String correoElectronico, String nombre, String nombreUsuario){

	}

	/**
	 * 
	 * @param numeroCuenta
	 */
	public void setNumeroCuenta(int numeroCuenta){

	}

	/**
	 * 
	 * @param numCuenta
	 */
	public void setNumeroCuenta(String numCuenta){

	}
}//end Monitor