

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:29
 */
public interface Interfaz Monitor {

	public void cobrar();

	public String getNumeroCuenta();

	/**
	 * 
	 * @param numCuenta
	 */
	public void setNumeroCuenta(String numCuenta);

}