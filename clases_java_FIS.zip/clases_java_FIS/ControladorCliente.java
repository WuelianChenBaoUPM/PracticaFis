

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:32
 */
public class ControladorCliente {

	public ViiewCliente m_ViiewCliente;
	public Cliente m_Cliente;

	public ControladorCliente(){

	}

	public void finalize() throws Throwable {

	}
	public Cliente crearCliente(){
		return null;
	}

	public String listaClientes(){
		return "";
	}
}//end ControladorCliente