

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:28
 */
public interface Interfaz Sesion {

	public String getActividad();

	public int getAforo();

	public String getHoraFin();

	public String getHoraInicio();

	/**
	 * 
	 * @param actividad
	 */
	public void setActividad(String actividad);

	/**
	 * 
	 * @param aforo
	 */
	public void setAforo(int aforo);

	/**
	 * 
	 * @param hora
	 */
	public void setHorafFin(String hora);

	/**
	 * 
	 * @param hora
	 */
	public void setHoraInicio(String hora);

}