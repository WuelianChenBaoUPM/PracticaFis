

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:33
 */
public class ControladorCurso {

	public Curso m_Curso;
	public viewCurso m_viewCurso;

	public ControladorCurso(){

	}

	public void finalize() throws Throwable {

	}
	public Curso crearCurso(){
		return null;
	}

	public String listaCursos(){
		return "";
	}
}//end ControladorCurso