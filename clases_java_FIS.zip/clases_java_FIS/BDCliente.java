

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:18
 */
public class BDCliente implements IAccesoBDCliente {

	public BDCliente(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param cliente
	 */
	public actualizar(Cliente cliente){

	}

	/**
	 * 
	 * @param cliente
	 */
	public borrar(Cliente cliente){

	}

	/**
	 * 
	 * @param cliente
	 */
	public insertar(Cliente cliente){

	}

	/**
	 * 
	 * @param cliente
	 */
	public seleccionar(Cliente cliente){

	}
}//end BDCliente