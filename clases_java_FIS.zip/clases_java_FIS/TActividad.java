

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:05
 */
public enum TActividad {
	baile,
	bicicleta,
	general,
	natacion,
	gimnasia,
	relax
}