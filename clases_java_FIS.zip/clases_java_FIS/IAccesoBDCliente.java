

/**
 * @author The Administrator
 * @version 1.0
 * @created 25-abr.-2023 17:33:17
 */
public interface IAccesoBDCliente {

	/**
	 * 
	 * @param cliente
	 */
	public actualizar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public borrar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public insertar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public seleccionar(Cliente cliente);

}