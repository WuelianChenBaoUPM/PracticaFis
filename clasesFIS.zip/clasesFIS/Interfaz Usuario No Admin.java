

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:20
 */
public interface Interfaz Usuario No Admin {

	public String getDNI();

	/**
	 * 
	 * @param DNI
	 */
	public void setDNI(String DNI);

}