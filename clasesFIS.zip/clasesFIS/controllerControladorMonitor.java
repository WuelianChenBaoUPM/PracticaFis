

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:24
 */
public class <<controller>>ControladorMonitor {

	public Interfaz Grafica Monitor m_Interfaz Grafica Monitor;
	public Interfaz Monitor m_Interfaz Monitor;

	public <<controller>>ControladorMonitor(){

	}

	public void finalize() throws Throwable {

	}
	public int getNumeroCuenta(){
		return 0;
	}
}//end <<controller>>ControladorMonitor