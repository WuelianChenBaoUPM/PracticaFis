

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:03
 */
public interface IAccesoBDAdmin {

	/**
	 * 
	 * @param admin
	 */
	public actualizar(Administrador admin);

	/**
	 * 
	 * @param num
	 */
	public borrar(int num);

	/**
	 * 
	 * @param admin
	 */
	public insertar(Administrador admin);

	/**
	 * 
	 * @param num
	 */
	public seleccionar(int num);

}