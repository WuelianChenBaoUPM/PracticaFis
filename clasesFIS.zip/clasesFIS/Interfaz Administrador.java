

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:16
 */
public interface Interfaz Administrador {

	public void altaMonitor();

	public double getTelefono();

	/**
	 * 
	 * @param numTelefono
	 */
	public void setNumTelefono(double numTelefono);

}