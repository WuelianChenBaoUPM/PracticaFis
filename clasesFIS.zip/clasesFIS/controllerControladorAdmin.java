

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:22
 */
public class <<controller>>ControladorAdmin {

	public Interfaz Gr�fica Administrador m_Interfaz Gr�fica Administrador;
	public Administrador m_Administrador;

	public <<controller>>ControladorAdmin(){

	}

	public void finalize() throws Throwable {

	}
	public int getTelefono(){
		return 0;
	}
}//end <<controller>>ControladorAdmin