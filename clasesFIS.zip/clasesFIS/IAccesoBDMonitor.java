

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:11
 */
public interface IAccesoBDMonitor {

	/**
	 * 
	 * @param monitor
	 */
	public actualizar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public borrar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public insertar(Monitor monitor);

	/**
	 * 
	 * @param monitor
	 */
	public seleccionar(Monitor monitor);

}