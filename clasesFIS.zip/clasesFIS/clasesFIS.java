

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:24
 */
public class <<controller>>ControladorCurso {

	public Curso m_Curso;
	public Interfaz Gr�fica Curso m_Interfaz Gr�fica Curso;

	public <<controller>>ControladorCurso(){

	}

	public void finalize() throws Throwable {

	}
	public int getFechaFin(){
		return 0;
	}

	public int getFechaInicio(){
		return 0;
	}

	public int getHorario(){
		return 0;
	}

	public int getNombre(){
		return 0;
	}
}//end <<controller>>ControladorCurso