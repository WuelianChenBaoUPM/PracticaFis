

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:22
 */
public class <<controller>ControladorUsGenerico {

	public UsuarioGenerico m_UsuarioGenerico;
	public Interfaz Gr�fica Usuario Gen�rico m_Interfaz Gr�fica Usuario Gen�rico;

	public <<controller>ControladorUsGenerico(){

	}

	public void finalize() throws Throwable {

	}
	public String getContrase�a(){
		return "";
	}

	public String getCorreo(){
		return "";
	}

	public String getDatos(){
		return "";
	}

	public String getNombre(){
		return "";
	}

	public String getNombreUs(){
		return "";
	}
}//end <<controller>ControladorUsGenerico