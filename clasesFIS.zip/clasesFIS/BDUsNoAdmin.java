

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:05
 */
public class BDUsNoAdmin implements IAccesoBDUSNoAdmin {

	public BDUsNoAdmin(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param usNoAdmin
	 */
	public actualizar(UsuarioNoAdmin usNoAdmin){

	}

	/**
	 * 
	 * @param dni
	 */
	public borrar(String dni){

	}

	/**
	 * 
	 * @param usNoAdmin
	 */
	public insertar(UsuarioNoAdmin usNoAdmin){

	}

	/**
	 * 
	 * @param dni
	 */
	public seleccionar(String dni){

	}
}//end BDUsNoAdmin