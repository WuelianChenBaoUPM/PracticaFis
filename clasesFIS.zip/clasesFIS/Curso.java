

/**
 * omb
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:52
 */
public class Curso implements Interfaz Curso {

	private int fechaFIn;
	private int fechaInicio;
	private int horario;
	private String nombre;
	public SesionCerrada SesionCerrada;
	public <<controlador>> ListaCursos m_<<controlador>> ListaCursos;

	public Curso(){

	}

	public void finalize() throws Throwable {

	}
	public destroy(){

	}

	public int getFechaFin(){
		return 0;
	}

	public int getFechaInicio(){
		return 0;
	}

	public int getHorario(){
		return 0;
	}

	public String getNombre(){
		return "";
	}

	/**
	 * 
	 * @param fechaInicio
	 * @param fechaFin
	 * @param horario
	 * @param nombre
	 */
	public new(int fechaInicio, int fechaFin, int horario, String nombre){

	}

	public void setFechaFin(){

	}

	public void setFechaInicio(){

	}

	public void setHorario(){

	}

	public void setNombre(){

	}

	public void visualizarInformacion(){

	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaFin(date fecha){

	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaInicio(date fecha){

	}

	/**
	 * 
	 * @param horario
	 */
	public void setHorario(String horario){

	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre){

	}
}//end Curso