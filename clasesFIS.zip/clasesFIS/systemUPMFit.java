

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:21
 */
public class <<system>>UPMFit {

	public <<controller>ControladorUsGenerico m_<<controller>ControladorUsGenerico;
	public <<controller>>ControladorAdmin m_<<controller>>ControladorAdmin;
	public <<controller>>ControladorCliente m_<<controller>>ControladorCliente;
	public <<controller>>ControladorMonitor m_<<controller>>ControladorMonitor;
	public Interfaz Gr�fica Curso m_Interfaz Gr�fica Curso;

	public <<system>>UPMFit(){

	}

	public void finalize() throws Throwable {

	}
	private void init(){

	}

	public void main(){

	}

	public String operate(){
		return "";
	}
}//end <<system>>UPMFit