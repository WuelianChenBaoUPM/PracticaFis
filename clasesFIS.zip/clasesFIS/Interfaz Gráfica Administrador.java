

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:57
 */
public class Interfaz Gr�fica Administrador {

	public Interfaz Gr�fica Administrador(){

	}

	public void finalize() throws Throwable {

	}
	public int getTelefono(){
		return 0;
	}

	public void setTelefono(){

	}
}//end Interfaz Gr�fica Administrador