

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:06
 */
public interface IAccesoBDCliente {

	/**
	 * 
	 * @param cliente
	 */
	public actualizar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public borrar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public insertar(Cliente cliente);

	/**
	 * 
	 * @param cliente
	 */
	public seleccionar(Cliente cliente);

}