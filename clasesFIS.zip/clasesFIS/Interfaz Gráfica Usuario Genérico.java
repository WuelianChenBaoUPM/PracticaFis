

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:56
 */
public class Interfaz Gr�fica Usuario Gen�rico {

	public Interfaz Gr�fica Usuario Gen�rico(){

	}

	public void finalize() throws Throwable {

	}
	public String getContrase�a(){
		return "";
	}

	public String getCorreo(){
		return "";
	}

	public void getDatos(){

	}

	public String getNombre(){
		return "";
	}

	public String getNombreUsuario(){
		return "";
	}

	/**
	 * 
	 * @param contrase�a
	 */
	public void setContrase�a(String contrase�a){

	}

	/**
	 * 
	 * @param correo
	 */
	public void setCorreo(String correo){

	}

	/**
	 * 
	 * @param contrase�a
	 * @param correo
	 * @param nombre
	 * @param nombreUsuario
	 */
	public void setDatos(String contrase�a, String correo, String nombre, String nombreUsuario){

	}

	public void setNombre(){

	}

	public void setNombreUsuario(){

	}
}//end Interfaz Gr�fica Usuario Gen�rico