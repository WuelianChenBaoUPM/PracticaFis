

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:23
 */
public class <<controller>>ControladorCliente {

	public Interfaz Gr�fica Cliente m_Interfaz Gr�fica Cliente;
	public Cliente m_Cliente;

	public <<controller>>ControladorCliente(){

	}

	public void finalize() throws Throwable {

	}
	public int getEdad(){
		return 0;
	}

	public double getPeso(){
		return 0;
	}

	public String getSexo(){
		return "";
	}

	public int getTarjeta(){
		return 0;
	}
}//end <<controller>>ControladorCliente