

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:49
 */
public class UsuarioNoAdmin extends UsuarioGenerico implements Interfaz Usuario No Admin {

	private String dni;

	public UsuarioNoAdmin(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public destroy(){

	}

	public String getdni(){
		return "";
	}

	/**
	 * 
	 * @param dni
	 * @param contrase�a
	 * @param correoElectronico
	 * @param nombre
	 * @param nombreUsuario
	 */
	public new(String dni, String contrase�a, String correoElectronico, String nombre, String nombreUsuario){

	}

	/**
	 * 
	 * @param dni
	 */
	public void setdni(String dni){

	}

	public String getDNI(){
		return "";
	}

	/**
	 * 
	 * @param DNI
	 */
	public void setDNI(String DNI){

	}
}//end UsuarioNoAdmin