

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:17
 */
public interface Interfaz Cliente {

	public int getEdad();

	public float getPeso();

	public String getSexo();

	public String getTarjeta();

	/**
	 * 
	 * @param edad
	 */
	public void setEdad(int edad);

	/**
	 * 
	 * @param peso
	 */
	public void setPeso(float peso);

	/**
	 * 
	 * @param sexo
	 */
	public void setSexo(String sexo);

	/**
	 * 
	 * @param tarjeta
	 */
	public void setTarjeta(String tarjeta);

}