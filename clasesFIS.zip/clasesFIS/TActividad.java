

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:53
 */
public enum TActividad {
	baile,
	bicicleta,
	general,
	natacion,
	gimnasia,
	relax
}