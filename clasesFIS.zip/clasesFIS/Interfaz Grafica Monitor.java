

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:19
 */
public class Interfaz Grafica Monitor {

	public Interfaz Grafica Monitor(){

	}

	public void finalize() throws Throwable {

	}
	public void cobrar(){

	}

	public String getNumeroCuenta(){
		return "";
	}

	/**
	 * 
	 * @param numCuenta
	 */
	public void setNumeroCuenta(String numCuenta){

	}
}//end Interfaz Grafica Monitor