

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:19
 */
public interface Interfaz Monitor {

	public void cobrar();

	public String getNumeroCuenta();

	/**
	 * 
	 * @param numCuenta
	 */
	public void setNumeroCuenta(String numCuenta);

}