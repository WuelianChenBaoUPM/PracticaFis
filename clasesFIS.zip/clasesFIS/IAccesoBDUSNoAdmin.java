

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:04
 */
public interface IAccesoBDUSNoAdmin {

	/**
	 * 
	 * @param usNoAdmin
	 */
	public actualizar(UsuarioNoAdmin usNoAdmin);

	/**
	 * 
	 * @param dni
	 */
	public borrar(String dni);

	/**
	 * 
	 * @param usNoAdmin
	 */
	public insertar(UsuarioNoAdmin usNoAdmin);

	/**
	 * 
	 * @param dni
	 */
	public seleccionar(String dni);

}