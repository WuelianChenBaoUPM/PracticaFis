

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:00
 */
public class Interfaz Gr�fica Curso {

	public Interfaz Gr�fica Curso(){

	}

	public void finalize() throws Throwable {

	}
	public void getDatos(){

	}

	public date getFechaFin(){
		return null;
	}

	public date getFechaInicio(){
		return null;
	}

	public String getHorario(){
		return "";
	}

	public String getNombre(){
		return "";
	}

	/**
	 * 
	 * @param horario
	 * @param fechaFin
	 * @param fechaInicio
	 * @param nombre
	 */
	public void setDatos(String horario, date fechaFin, date fechaInicio, String nombre){

	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaFin(date fecha){

	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFechaInicio(date fecha){

	}

	/**
	 * 
	 * @param horario
	 */
	public void setHorario(String horario){

	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre){

	}
}//end Interfaz Gr�fica Curso