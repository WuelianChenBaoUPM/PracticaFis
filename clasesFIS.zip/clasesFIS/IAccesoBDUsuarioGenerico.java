

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:02
 */
public interface IAccesoBDUsuarioGenerico {

	/**
	 * 
	 * @param usGenerico
	 */
	public actualizar(UsuarioGenerico usGenerico);

	/**
	 * 
	 * @param nombreUsuario
	 */
	public borrar(String nombreUsuario);

	/**
	 * 
	 * @param usGenerico
	 */
	public insertar(UsuarioGenerico usGenerico);

	/**
	 * 
	 * @param nombreUsuario
	 */
	public seleccionar(String nombreUsuario);

}