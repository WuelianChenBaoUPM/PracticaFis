

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:01
 */
public class Interfaz Gr�fica Cliente {

	public Interfaz Gr�fica Cliente(){

	}

	public void finalize() throws Throwable {

	}
	public void getDatos(){

	}

	public int getEdad(){
		return 0;
	}

	public float getPeso(){
		return null;
	}

	public String getSexo(){
		return "";
	}

	public String getTarjeta(){
		return "";
	}

	/**
	 * 
	 * @param tarjeta
	 * @param sexo
	 * @param peso
	 * @param edad
	 */
	public void setDatos(String tarjeta, String sexo, float peso, int edad){

	}

	/**
	 * 
	 * @param edad
	 */
	public void setEdad(int edad){

	}

	/**
	 * 
	 * @param peso
	 */
	public void setPeso(float peso){

	}

	/**
	 * 
	 * @param sexo
	 */
	public void setSexo(String sexo){

	}

	/**
	 * 
	 * @param tarjeta
	 */
	public void setTarjeta(String tarjeta){

	}
}//end Interfaz Gr�fica Cliente