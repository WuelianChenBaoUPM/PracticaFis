

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:30:58
 */
public class Interfaz Gr�fica Usuario No Admin {

	public Interfaz Gr�fica Usuario No Admin(){

	}

	public void finalize() throws Throwable {

	}
	public String getDNI(){
		return "";
	}

	/**
	 * 
	 * @param DNI
	 */
	public void setDNI(String DNI){

	}
}//end Interfaz Gr�fica Usuario No Admin