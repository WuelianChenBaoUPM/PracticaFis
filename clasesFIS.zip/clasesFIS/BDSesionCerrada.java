

/**
 * @author The Administrator
 * @version 1.0
 * @created 21-abr.-2023 11:31:11
 */
public class BDSesionCerrada implements IAccesoBDSesionCerrada {

	public BDSesionCerrada(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param sesionCerrada
	 */
	public void actualizar(SesionCerrada sesionCerrada){

	}

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void borrar(SesionCerrada sesionCerrada){

	}

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void insertar(SesionCerrada sesionCerrada){

	}

	/**
	 * 
	 * @param sesionCerrada
	 */
	public void seleccionar(SesionCerrada sesionCerrada){

	}
}//end BDSesionCerrada